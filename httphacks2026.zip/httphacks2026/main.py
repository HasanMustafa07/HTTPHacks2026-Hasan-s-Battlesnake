# Welcome to
# __________         __    __  .__                               __
# \______   \_____ _/  |__/  |_|  |   ____   ______ ____ _____  |  | __ ____
#  |    |  _/\__  \\   __\   __\  | _/ __ \ /  ___//    \\__  \ |  |/ // __ \
#  |    |   \ / __ \|  |  |  | |  |_\  ___/ \___ \|   |  \/ __ \|    <\  ___/
#  |________/(______/__|  |__| |____/\_____>______>___|__(______/__|__\\_____>
#
# This file can be a nice home for your Battlesnake logic and helper functions.
#
# To get you started we've included code to prevent your Battlesnake from moving backwards.
# For more info see docs.battlesnake.com

import random
import typing


# info is called when you create your Battlesnake on play.battlesnake.com
# and controls your Battlesnake's appearance
# TIP: If you open your Battlesnake URL in a browser you should see this data
def info() -> typing.Dict:
    print("INFO")

    return {
        "apiversion": "1",
        "author": "",  # TODO: Your Battlesnake Username
        "color": "#FFA600",  # TODO: Choose color
        "head": "sand-worm",  # TODO: Choose head
        "tail": "block-bum",  # TODO: Choose tail
    }


# start is called when your Battlesnake begins a game
def start(game_state: typing.Dict):
    print("GAME START")


# end is called when your Battlesnake finishes a game
def end(game_state: typing.Dict):
    print("GAME OVER\n")


# move is called on every turn and returns your next move
# Valid moves are "up", "down", "left", or "right"
# See https://docs.battlesnake.com/api/example-move for available data
def move(game_state: typing.Dict) -> typing.Dict:

    is_move_safe = {"up": True, "down": True, "left": True, "right": True}

    # We've included code to prevent your Battlesnake from moving backwards
    my_head = game_state["you"]["body"][0]  # Coordinates of your head
    my_neck = game_state["you"]["body"][1]  # Coordinates of your "neck"

    if my_neck["x"] < my_head["x"]:  # Neck is left of head, don't move left
        is_move_safe["left"] = False

    elif my_neck["x"] > my_head["x"]:  # Neck is right of head, don't move right
        is_move_safe["right"] = False

    elif my_neck["y"] < my_head["y"]:  # Neck is below head, don't move down
        is_move_safe["down"] = False

    elif my_neck["y"] > my_head["y"]:  # Neck is above head, don't move up
        is_move_safe["up"] = False

    # Code to not hit the walls
    # TODO: Step 1 - Prevent your Battlesnake from moving out of bounds
        # board_width = game_state['board']['width']
        # board_height = game_state['board']['height']

    board_width = game_state["board"]["width"]
    board_height = game_state["board"]["height"]

    if my_head["x"] == 0:
        is_move_safe['left'] = False
    if my_head["x"] == board_width -1:
        is_move_safe['right'] = False
    if my_head["y"] == 0:
        is_move_safe['down'] = False
    if my_head['y'] == board_height - 1:
        is_move_safe['up'] = False

    # code to not run into snake body parts
    # TODO: Step 2 - Prevent your Battlesnake from colliding with itself
    # my_body = game_state['you']['body']
    # TODO: Step 3 - Prevent your Battlesnake from colliding with other Battlesnakes
    # opponents = game_state['board']['snakes']

    for snake in game_state['board']['snakes']:
        for segment in snake['body']:
            if my_head['x'] - 1 == segment['x'] and my_head['y'] == segment['y']:
                is_move_safe['left'] = False
            if my_head['x'] + 1 == segment['x'] and my_head['y'] == segment ['y']:
                is_move_safe['right'] = False
            if my_head['y'] - 1 == segment['y'] and my_head['x'] == segment['x']:
                is_move_safe['down'] = False
            if my_head['y'] + 1 == segment['y'] and my_head['x'] == segment['x']:
                is_move_safe['up'] = False

    safe_moves = [m for m, ok in is_move_safe.items() if ok]

    if len(safe_moves) == 0:
        print(f'MOVE {game_state['turn']}: no safe moves, moving down')
        return {"move": "down"}

    #snake avoids trapping itself in walled off areas
    my_length = len(game_state['you']['body'])
    blocked = set()
    for snake in game_state['board']['snakes']:
        for segment in snake['body']:
            blocked.add((segment['x'], segment['y']))

    def open_space(start_x, start_y):
        seen = set()
        to_visit = [(start_x, start_y)]
        while to_visit:
            x, y = to_visit.pop()
            if (x, y) in seen or (x, y) in blocked:
                continue
            if x < 0 or x >= board_width or y < 0 or y >= board_height:
                continue
            seen.add((x, y))
            to_visit.append((x + 1, y))
            to_visit.append((x - 1, y))
            to_visit.append((x, y + 1))
            to_visit.append((x, y - 1))
        return len(seen)

    step = {'up': (0, 1), 'down': (0, -1), 'left': (-1, 0), 'right': (1, 0)}
    space = {}
    for m in safe_moves:
        dx, dy = step[m]
        space[m] = open_space(my_head['x'] + dx, my_head['y'] + dy)

    roomy_moves = [m for m in safe_moves if space[m] >= my_length]
    if not roomy_moves:
        best = max(space.values())
        roomy_moves = [m for m in safe_moves if space[m] == best]

    safe_moves = roomy_moves


    #COULDNT GET THIS DONE IN TIME 
    # my_id = game_state['you']['id']
    # my_length = len(game_state['you']['body'])

    # danger_sqaures = set()
    # target_sqaure = set()

    # for snake in game_state['board']['snakes']:
    #     if snake['id'] == my_id:
    #         continue

    #     head = snake['body'][0]
    #     neck = snake['body'][1]

    #     for dx, dy in [(0, 1), (0, -1), (-1, 0), (1, 0)]:
    #         sqaure = (head['x'] + dx, head['y']):

    #         if sqaure == (next['x'], neck['y']):
    #             continue

    #         if len(snake['body']) >= my_length:
    #             danger_sqaures.add(sqaure)
    #         else:
    #             target_sqaure.add(sqaure)

    # cautious_moves = []

    # for m in safe_moves:
    #     dx, dy = step[m]
    #     sqaure = (my_head['x'] + dx, my_head['y'] + dy)
    #     if sqaure not in danger_sqaures:
    #         cautious_moves.append(m)

    # if cautious_moves:
    #     safe_moves = cautious_moves

    

    # snake goes to closest food
    food = game_state['board']['food']
    next_move = random.choice(safe_moves)

    def distance_to_head(f):
        return abs(f['x'] - my_head['x']) + abs(f['y'] - my_head['y'])

    closest = None
    closest_distance = 9999

    for f in food:
        distance = abs(f["x"] - my_head["x"]) + abs(f["y"] - my_head["y"])
        if distance < closest_distance:
            closest_distance = distance
            closest = f

    good_moves = []
    if closest['x'] < my_head['x'] and 'left' in safe_moves:
        good_moves.append('left')
    if closest['x'] > my_head['x'] and 'right' in safe_moves:
        good_moves.append('right')
    if closest['y'] < my_head['y'] and 'down' in safe_moves:
        good_moves.append('down')
    if closest['y'] > my_head['y'] and 'up' in safe_moves:
        good_moves.append('up')

    if good_moves:
        next_move = random.choice(good_moves)

    return {'move': next_move}
    

    

    #     next_move = random.choice(safe_moves)
    # print(f'MOVE {game_state['turn']}: {next_move}')
    # return {'move': next_move}



    # Are there any safe moves left?
    safe_moves = []
    for move, isSafe in is_move_safe.items():
        if isSafe:
            safe_moves.append(move)

    if len(safe_moves) == 0:
        print(f"MOVE {game_state['turn']}: No safe moves detected! Moving down")
        return {"move": "down"}

    # Choose a random move from the safe ones
    next_move = random.choice(safe_moves)

    # TODO: Step 4 - Move towards food instead of random, to regain health and survive longer
    # food = game_state['board']['food']

    print(f"MOVE {game_state['turn']}: {next_move}")
    return {"move": next_move}


# Start server when `python main.py` is run
if __name__ == "__main__":
    from server import run_server

    run_server({"info": info, "start": start, "move": move, "end": end})
